import discord
import random
from datetime import datetime

intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

import os
TOKEN = os.getenv("DISCORD_TOKEN")


@client.event
async def on_ready():
    print(f'✅ Logged in as {client.user}')


@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.startswith('!hello'):
        await message.channel.send(f"Hey {message.author.name}! 👋")

    elif message.content.startswith('!quote'):
        quotes = [
            "Keep pushing forward 🚀",
            "You miss 100% of the shots you don’t take.",
            "Success is built on consistency, not talent."
        ]
        await message.channel.send(random.choice(quotes))

    elif message.content.startswith('!time'):
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        await message.channel.send(f"The current time is: {now}")


client.run(TOKEN)
